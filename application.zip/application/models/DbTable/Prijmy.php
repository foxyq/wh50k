<?php

class Application_Model_DbTable_Prijmy extends Zend_Db_Table_Abstract
{
	//namapovanie tabuľky podľa mena z databáze pre aplikáciu
    protected $_name = 'ts_prijmy';
/*
    protected $referenceMap = array(
    	'Sklad'=>array(
    		'columnes'=>array('sklady_id'),
    		'refTableClass'=>'Sklady',
    		'refColumns'=>array();


    		)


    	);*/




}

